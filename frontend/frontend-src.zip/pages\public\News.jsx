import Navbar from "../../components/Navbar";

const news = [
  {
    date: "12 Sep 2026",
    category: "Academic",
    title: "New Academic Session Begins",
    description:
      "The new academic session begins with orientation programs and exciting learning activities.",
  },
  {
    date: "05 Sep 2026",
    category: "School",
    title: "Teachers' Day Celebration",
    description:
      "Students celebrated Teachers' Day with performances, speeches and appreciation activities.",
  },
  {
    date: "28 Aug 2026",
    category: "Achievement",
    title: "Students Excel in Inter-School Competition",
    description:
      "Our students achieved outstanding results in various inter-school competitions.",
  },
  {
    date: "18 Aug 2026",
    category: "Sports",
    title: "Annual Sports Training Begins",
    description:
      "Students started preparation and training for the upcoming annual sports meet.",
  },
  {
    date: "10 Aug 2026",
    category: "Technology",
    title: "New Smart Classrooms Introduced",
    description:
      "AXIS School expands technology-enabled learning with new smart classroom facilities.",
  },
  {
    date: "02 Aug 2026",
    category: "Community",
    title: "Community Outreach Program",
    description:
      "Students and teachers participated in a community service and awareness program.",
  },
];

function News() {
  return (
    <>
      <Navbar />

      <section className="page-hero">
        <div>
          <span>SCHOOL NEWS</span>

          <h1>Latest News & Updates</h1>

          <p>
            Stay informed about the latest happenings,
            achievements and announcements at AXIS School.
          </p>
        </div>
      </section>

      <section className="content-section">

        <div className="section-heading">
          <span>NEWS & UPDATES</span>

          <h2>What's New at AXIS</h2>

          <p>
            Discover the latest school activities and
            achievements.
          </p>
        </div>

        <div className="news-grid">

          {news.map((item) => (
            <article className="news-card" key={item.title}>

              <div className="news-top">
                <span>{item.category}</span>
                <small>{item.date}</small>
              </div>

              <h3>{item.title}</h3>

              <p>{item.description}</p>

              <button>
                Read More →
              </button>

            </article>
          ))}

        </div>

      </section>
    </>
  );
}

export default News;