import { Routes, Route } from "react-router-dom";

// ==========================================
// PUBLIC PAGES
// ==========================================

import Home from "./pages/public/Home";
import About from "./pages/public/About";
import Academics from "./pages/public/Academics";
import Classes from "./pages/public/Classes";
import Faculty from "./pages/public/Faculty";
import Facilities from "./pages/public/Facilities";
import Gallery from "./pages/public/Gallery";
import Events from "./pages/public/Events";
import News from "./pages/public/News";
import Admissions from "./pages/public/Admissions";
import Contact from "./pages/public/Contact";
import FAQ from "./pages/public/FAQ";

// ==========================================
// AUTH PAGES
// ==========================================

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

// ==========================================
// STUDENT
// ==========================================

import StudentDashboard from "./pages/student/StudentDashboard";

import ProtectedRoute from "./components/ProtectedRoute";
import Footer from "./components/Footer";

function StudentDashboardPage() {
  return (
    <ProtectedRoute role="student">
      <StudentDashboard />
    </ProtectedRoute>
  );
}

function ParentDashboard() {
  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-card">
          <div className="dashboard-icon">👨‍👩‍👧</div>

          <h1>Parent Dashboard</h1>

          <p>
            Welcome to the AXIS School parent portal.
          </p>

          <p>
            Your child attendance, results, fees and
            school activities will appear here.
          </p>
        </div>
      </div>
    </div>
  );
}

function TeacherDashboard() {
  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-card">
          <div className="dashboard-icon">👨‍🏫</div>

          <h1>Teacher Dashboard</h1>

          <p>
            Welcome to the AXIS School teacher portal.
          </p>

          <p>
            Classes, attendance, homework, results and
            students will appear here.
          </p>
        </div>
      </div>
    </div>
  );
}


// ==========================================
// ADMIN DASHBOARD
// ==========================================

function AdminDashboard() {
  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-card">
          <div className="dashboard-icon">⚙️</div>

          <h1>Admin Dashboard</h1>

          <p>
            Welcome to the AXIS School administration panel.
          </p>

          <p>
            Students, teachers, attendance, fees, notices,
            admissions and reports will appear here.
          </p>
        </div>
      </div>
    </div>
  );
}


// ==========================================
// 404 PAGE
// ==========================================

function NotFound() {
  return (
    <div className="not-found-page">

      <div className="not-found-card">

        <div className="not-found-number">
          404
        </div>

        <h1>Page Not Found</h1>

        <p>
          Sorry, the page you are looking for does not exist.
        </p>

        <a href="/" className="not-found-btn">
          ← Back to Home
        </a>

      </div>

    </div>
  );
}


// ==========================================
// MAIN APP
// ==========================================

function App() {
  return (
    <>

      {/* ======================================
          ROUTES
      ====================================== */}

      <Routes>

        {/* ==================================
            PUBLIC WEBSITE
        ================================== */}

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/about"
          element={<About />}
        />

        <Route
          path="/academics"
          element={<Academics />}
        />

        <Route
          path="/classes"
          element={<Classes />}
        />

        <Route
          path="/faculty"
          element={<Faculty />}
        />

        <Route
          path="/facilities"
          element={<Facilities />}
        />

        <Route
          path="/gallery"
          element={<Gallery />}
        />

        <Route
          path="/events"
          element={<Events />}
        />

        <Route
          path="/news"
          element={<News />}
        />

        <Route
          path="/admissions"
          element={<Admissions />}
        />

        <Route
          path="/contact"
          element={<Contact />}
        />

        <Route
          path="/faq"
          element={<FAQ />}
        />


        {/* ==================================
            AUTHENTICATION
        ================================== */}

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />


        {/* ==================================
            STUDENT PORTAL
        ================================== */}

        <Route
          path="/student/dashboard"
          element={<StudentDashboardPage />}
        />


        {/* ==================================
            PARENT PORTAL
        ================================== */}

        <Route
          path="/parent/dashboard"
          element={
            <ProtectedRoute role="parent">
              <ParentDashboard />
            </ProtectedRoute>
          }
        />


        {/* ==================================
            TEACHER PORTAL
        ================================== */}

        <Route
          path="/teacher/dashboard"
          element={
            <ProtectedRoute role="teacher">
              <TeacherDashboard />
            </ProtectedRoute>
          }
        />


        {/* ==================================
            ADMIN PORTAL
        ================================== */}

        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />


        {/* ==================================
            404
        ================================== */}

        <Route
          path="*"
          element={<NotFound />}
        />

      </Routes>


      {/* ======================================
          FOOTER
      ====================================== */}

      <Footer />

    </>
  );
}


export default App;